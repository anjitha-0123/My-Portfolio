import React from 'react'

function Education() {
  return (
    <div className='text-center top-6 bg-black placeholder-wave' id='Education' >
        <h3 className='text-danger top-12'>Education</h3>
        <div>
        <h4>PG Diploma in Blockchain</h4>
        <p >Digital UNiversity Kerala</p>
        <p>2024-2025</p>
        </div>

        <div>
            <h4>B.Tech</h4>
            <p>Electronics and Communication Engineering</p>
            <p>Government Engineering College</p>
            <p>KTU 2018-2022</p>
        </div>
        </div>
        
  )
}

export default Education